/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void stringReverse(char str[])
{
    if (str[0] != '\0')
    {
        stringReverse(str + 1);
        printf("%c", str[0]);
    }
}

int main()
{
    char str[60]; 
    printf("請輸入一個字串：\n"); 
    scanf("%s", str); 
    printf("反向印出字串：\n"); 
    stringReverse(str); 
    printf("\n"); 
    return 0;
}